
import Head from 'next/head';

export default function Page() {
  return (
    <>
      <Head>
        <title>IOUL</title>
        <link rel="icon" href="/favicon.png" type="image/png" />
        <link rel="stylesheet" href="/styles.css" />
      </Head>
      <div dangerouslySetInnerHTML={ { __html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>IOUL</title>
  <link rel="icon" href="favicon.png" type="image/png" />
  <link rel="stylesheet" href="styles.css" />
  <style>
    .login-text {
      position: absolute;
      left: 6.41vw;
      z-index: 10;
      overflow: visible;
      font-family: 'Distill Expanded', sans-serif;
      color: #111111;
      letter-spacing: 0.34vw;
      font-size: 0.46rem;
      line-height: 1.2;
      padding: 0.1rem 0;
      text-shadow: 0.001rem 0.001rem 0 #717171, -0.001rem -0.001rem 0 #717171;
    }

    input.typing-input {
      font-family: 'Distill Expanded', sans-serif;
      font-size: 0.46rem;
      line-height: 1.2;
      color: #111111;
      letter-spacing: 0.34vw;
      border: none;
      outline: none;
      background-color: transparent;
      position: absolute;
      caret-color: #717171;
      padding: 0.1rem 0;
      width: calc(22.48vw + 4vw);
      height: auto;
      box-sizing: content-box;
      text-shadow: 0.001rem 0.001rem 0 #717171, -0.007rem -0.001rem 0 #717171;
      text-align: left;
    }

    .help-text-area.sendlink {
      opacity: 0.7;
      transition: opacity 0.3s ease-in-out;
      line-height: 1.2;
      margin-top: -0.05rem;
      -webkit-font-smoothing: antialiased;
    }
    .help-text-area.sendlink:hover {
      opacity: 1;
    }
  </style>
</head>
<body class="non-fullscreen">
  <div class="line original"></div>
  <div class="line second"></div>
  <div class="line third"></div>
  <div class="line fourth"></div>
  <div class="line fifth"></div>
  <div class="line sixth"></div>

  <div class="line util-line"></div>

  <span class="login-text username">USERnAME</span>
  <span class="login-text password">PASSWORD</span>
  <span class="login-text open-text hidden">OPEn</span>
  <span class="login-text help-text hidden">HELP</span>

  <div class="line login-line"></div>
  <div class="line login-line-second"></div>

  <div class="account-wrapper">
    <span class="account-text account-email">E-MA1L ADDRESS</span>
    <span class="account-text account-username">YOUR USERnAME</span>
    <span class="account-text account-sign-password">YOUR PASSWORD</span>
    <span class="account-text account-repeat-password">REDO PASSWORD</span>
    <div class="account-line account-line1"></div>
    <div class="account-line account-line2"></div>
    <div class="account-line account-line3"></div>
    <div class="account-line account-line4"></div>
  </div>

  <div class="help-wrapper">
    <span class="help-text-area email">YOUR EMA1L</span>
    <span class="help-text-area sendlink">SEnD L1nK</span>
    <div class="help-line"></div>
  </div>



  <div class="layer-one"></div>
  <div class="layer-two"></div>




<script>
document.addEventListener('DOMContentLoaded', () => {
  /* ----- element groups -------------------------------------------------- */
  const loginEls      = document.querySelectorAll('.username, .password, .login-line, .login-line-second');
  const utilLine      = document.querySelector('.util-line');
  const openText      = document.querySelector('.open-text');
  const helpText      = document.querySelector('.help-text');
  const accountWrap   = document.querySelector('.account-wrapper');
  const helpWrap      = document.querySelector('.help-wrapper');

  /* ----- helper functions ------------------------------------------------- */
  const fadeInEls  = (els) => els.forEach(el => { el.classList.remove('hidden'); el.classList.add('visible'); });
  const fadeOutEls = (els) => Promise.all(Array.from(els).map(el => new Promise(res => {
      if (!el.classList.contains('visible')) { res(); return; }
      const end = (e)=>{ if(e.propertyName==='opacity'){ el.removeEventListener('transitionend', end); res(); } };
      el.addEventListener('transitionend', end);
      el.classList.add('hidden'); el.classList.remove('visible');
  })));

  const fadeInWrap = (wrap) => { wrap.classList.add('active'); };
  const fadeOutWrap = (wrap) => new Promise(res=>{
      if(!wrap.classList.contains('active')) { res(); return; }
      const end = (e)=>{ if(e.target===wrap && e.propertyName==='opacity'){ wrap.removeEventListener('transitionend', end); res(); }};
      wrap.addEventListener('transitionend', end);
      wrap.classList.remove('active');
  });

  /* ----- initial hover logic --------------------------------------------- */
  let phase = 0; // 0: waiting for first pointer -> lines fade. 1: waiting for login zone hover
  function inLoginZone(x,y){
      const vw=innerWidth, vh=innerHeight;
      return x>=vw*0.0641 && x<=vw*0.2886 && y>=vh*0.285 && y<=vh*0.84;
  }
  function initialPointer(e){
      const p=e.touches?e.touches[0]:e;
      const {clientX:x, clientY:y}=p;

      if(phase===0){
          document.body.classList.add('fade-in-trigger'); // lines & util fade in
          phase=1;
          return;
      }
      if(phase===1 && inLoginZone(x,y)){
          fadeInEls(loginEls);                            // login group fade in
          phase=2;
          window.removeEventListener('pointermove',initialPointer);
          window.removeEventListener('touchstart',initialPointer);
      }
  }
  window.addEventListener('pointermove', initialPointer, {passive:true});
  window.addEventListener('touchstart', initialPointer, {passive:true});

  /* ----- main sequential logic ------------------------------------------- */
  let step=0; // 0:login, 1:open/help, 2:account, 3:help

  utilLine.addEventListener('click', async ()=>{
      if(step!==0) return;
      await fadeOutEls(loginEls);
      fadeInEls([openText, helpText]);
      step=1;
  });

  openText.addEventListener('click', async ()=>{
      if(step!==1) return;
      await fadeOutEls([openText, helpText]);
      fadeInWrap(accountWrap);
      step=2;
  });

  helpText.addEventListener('click', async ()=>{
      if(step!==1) return;
      await fadeOutEls([openText, helpText]);
      fadeInWrap(helpWrap);
      step=3;
  });

  /* ----- inverse tap‑back zone ------------------------------------------- */
  document.addEventListener('click', async (e)=>{
      const {clientX:x, clientY:y}=e;
      const vw=innerWidth, vh=innerHeight;
      const back = x<=vw*0.0637 && y>=vh*0.285 && y<=vh*0.84;
      if(!back) return;

      if(step===1){ // open/help -> login
          await fadeOutEls([openText, helpText]);
          fadeInEls(loginEls);
          step=0;
      }else if(step===2){ // account -> open/help
          await fadeOutWrap(accountWrap);
          fadeInEls([openText, helpText]);
          step=1;
      }else if(step===3){ // help -> open/help
          await fadeOutWrap(helpWrap);
          fadeInEls([openText, helpText]);
          step=1;
      }
  });





/* ---- editable texts (single click everywhere, restore placeholder, exclude SEnD L1nK) ---- */
const editableSel = '.username, .password, .account-text, .help-text-area';

function findEditable(ev){
  let el = ev.target.closest(editableSel);
  if(!el){
    const alt = document.elementFromPoint(ev.clientX, ev.clientY);
    if(alt) el = alt.closest(editableSel);
  }
  return el;
}

document.addEventListener('pointerdown', (ev)=>{
  const el = findEditable(ev);
  if(!el) return;

  // skip send link
  if(/send\s*l1nk/i.test(el.textContent) || /send\s*link/i.test(el.textContent) ||
     el.classList.contains('send-link') || el.id === 'send-link') return;

  if(el.isContentEditable) return;
  ev.preventDefault();
  el.dataset.placeholder = el.textContent;
  el.textContent = '';
  el.setAttribute('contenteditable','true');
  el.focus({preventScroll:true});
}, true);

document.addEventListener('focusout', (ev)=>{
  const el = ev.target;
  if(!el || !el.matches || !el.matches(editableSel) || !el.isContentEditable) return;
  if(el.textContent.trim()===''){
    el.textContent = el.dataset.placeholder || '';
    el.removeAttribute('contenteditable');
  }
}, true);

  /* ---- edge‑click fullscreen (11px from any edge) ---- */
function toggleFullScreen(){
  if(!document.fullscreenElement){
    document.documentElement.requestFullscreen().catch(()=>{});
  }else{
    document.exitFullscreen().catch(()=>{});
  }
}
document.addEventListener('click', (ev) => {
  const x = ev.clientX, y = ev.clientY;
  if (x <= 11 || x >= innerWidth - 11 || y <= 11 || y >= innerHeight - 11) {
    toggleFullScreen();
  }
});
});
</script>

</body>
</html>
` } } />
    </>
  );
}
